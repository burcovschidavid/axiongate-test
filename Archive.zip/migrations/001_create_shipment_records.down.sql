DROP TABLE IF EXISTS shipment_records;
